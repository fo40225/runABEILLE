## ----style-knitr, eval=TRUE, echo=FALSE, cache=FALSE, results="asis"----------------
BiocStyle::latex()

## ----knitr, echo=FALSE, cache=FALSE, results="hide"---------------------------------
library(knitr)
library("crayon")
opts_chunk$set(
    tidy=FALSE,
    dev="png",
    fig.width=7,
    fig.height=7,
    dpi=300,
    message=FALSE,
    warning=FALSE,
    cache=TRUE
)

